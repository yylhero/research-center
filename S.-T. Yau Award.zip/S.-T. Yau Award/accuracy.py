import numpy as np

from sklearn.metrics import mean_squared_error as mse#均方误差
from sklearn.metrics import mean_absolute_error as mae #平方绝对误差

def RMSE(y_true, y_pred):
    RMSE = mse(y_true,y_pred)**0.5
    return RMSE
def MAE(y_true, y_pred):  
    MAE = mae(y_true,y_pred)
    return MAE
def MAPE(y_true, y_pred):
    n = len(y_true)
    MAPE = sum(abs((y_true - y_pred)/y_true))/n*100
    MAPE= MAPE[0]
    return MAPE

